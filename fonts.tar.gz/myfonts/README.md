Make ~/.local/share/fonts/ if it doesn't exist and run ./install.sh
