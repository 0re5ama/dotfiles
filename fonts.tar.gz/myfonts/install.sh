#!/bin/bash
BASEDIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

mv ${BASEDIR}/otf/* ~/.local/share/fonts/

